class LlmAgent:
  def handle(self, user, message):
    # 아주 단순한 LLM 흉내
    return f"{user}님, '{message}' 잘 받았습니다."