# 아직은 아무 기능도 없음
def fake_tool():
  return "result"