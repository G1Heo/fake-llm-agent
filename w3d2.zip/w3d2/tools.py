# 아직은 아무 기능도 없음
def fake_tool():
  return "result"

def get_weather(location):
  if location == "서울":
    return "맑음"
  return "모름"